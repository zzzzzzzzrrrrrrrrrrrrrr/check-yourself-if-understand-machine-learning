# Week 8 — RL (bandits intro)
**Theory**: ε‑greedy vs UCB; define regret.  
**Coding**: K=5 Bernoulli arms; ε‑greedy & UCB1; reward+regret plots.  
**Rubric**: UCB eventually > small‑ε greedy; reproducible.

# Week 2 — Logistic Regression
**Theory**: (1) Logistic loss convexity (intuitive); (2) L2 as MAP.  
**Coding**: From‑scratch logistic; compare with sklearn; AUC/ACC; L2 on/off.  
**Rubric**: AUC ≥0.85 (toy) or justify; learning curve + bias/variance note.

# Week 4 — Decision Trees (intro)
**Theory**: (1) Gini & info gain; (2) Why high variance; depth/leaf effects.  
**Coding**: Tune `max_depth`, `min_samples_leaf`; compare vs logistic on same data.  
**Rubric**: Proper CV; metric table + conclusion.

# Week 7 — Recommenders (intro)
**Theory**: user‑user vs item‑item; cold‑start remedies.  
**Coding**: User‑user CF (cosine) on toy ratings; top‑N; held‑out hit‑rate.  
**Rubric**: modular functions; hit‑rate reported.

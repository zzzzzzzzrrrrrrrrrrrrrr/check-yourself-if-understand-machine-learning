# Week 1 — Linear Regression
**Theory**: (1) Derive gradient of MSE; (2) Why scaling helps GD; (3) MAE vs MSE trade‑offs.  
**Coding**: NumPy GD implementation; plot loss; RMSE vs mean baseline.  
**Rubric**: finite‑diff check; RMSE improve ≥30%; clean modular code.

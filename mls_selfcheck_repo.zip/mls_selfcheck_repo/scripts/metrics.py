import numpy as np
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score, precision_recall_fscore_support
def rmse(y, yhat): return float(np.sqrt(mean_squared_error(y, yhat)))
def r2(y, yhat): return float(r2_score(y, yhat))
def cls_report(y, yhat):
    acc = float(accuracy_score(y, yhat))
    p, r, f1, _ = precision_recall_fscore_support(y, yhat, average="binary", zero_division=0)
    return {"accuracy": acc, "precision": float(p), "recall": float(r), "f1": float(f1)}

import pandas as pd
def load_csv(path, target=None):
    df = pd.read_csv(path)
    if target is None: return df
    X = df.drop(columns=[target]).values
    y = df[target].values
    return X, y

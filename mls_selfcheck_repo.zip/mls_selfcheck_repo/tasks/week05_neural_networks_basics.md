# Week 5 — Neural Networks (basics)
**Theory**: (1) 2‑layer MLP forward/backprop; (2) Why ReLU helps.  
**Coding**: NumPy MLP on binary toy; compare sklearn MLPClassifier.  
**Rubric**: ≥95% train acc (separable); curves + early stopping.

# Week 3 — Model Selection
**Theory**: (1) Train/Val/Test; (2) Two leakage examples + fixes.  
**Coding**: k‑fold CV; slice error analysis.  
**Rubric**: CV mean±std; worst 2 slices + hypotheses.

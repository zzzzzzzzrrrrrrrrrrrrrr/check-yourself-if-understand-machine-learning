# Week 6 — Unsupervised
**Theory**: (1) k‑means objective + steps; (2) PCA 1st component maximizes variance.  
**Coding**: k in [2..8] elbow+silhouette; PCA EVR + 2D plot.  
**Rubric**: Plots + short interpretation.
